﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bai_2
{
    public partial class FrmTBGiaoVien : Form
    {
        public FrmTBGiaoVien()
        {
            InitializeComponent();
        }
        public void SetText (string s)
        {
            this.lblThongBao.Text = s;  
        }
        private void lblThongBao_Click(object sender, EventArgs e)
        {

        }
    }
}
