﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai_2
{
    internal class Giaovien
    {
        public string MaSo { get; set; }
        public string HoTen { get; set; }
        public DateTime NgaySinh;
        public DanhMucMonHoc dsMonHoc;
        public string GioiTinh;
        public string[] NgoaiNgu;
        public string SoDT;
        public string Mail;
        public Giaovien()
        {
            dsMonHoc = new DanhMucMonHoc();
            NgoaiNgu = new string[10];

        }
        public Giaovien (string maso, string hoten, DateTime ngaysinh,
            DanhMucMonHoc ds, string gt, string[]nn, string sdt, string mail)
        {
            this .MaSo = maso;
            this.HoTen = hoten;
            this.NgaySinh = ngaysinh; 
            this.dsMonHoc = ds;

        }
    }
}
