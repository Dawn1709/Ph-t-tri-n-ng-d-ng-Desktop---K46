﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Printing;

namespace Lab06_Basic_Command
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            string connectionString = "server=.; database = RestaurantManagement; Integrated Security = true;";
            SqlConnection sqlConnection= new SqlConnection(connectionString);
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            string query = "Select ID, Name, Type From Category";
            sqlCommand.CommandText = query;
            sqlConnection.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);
            adapter.Fill(dt);
            foreach(DataRow row in dt.Rows)
            {
                ListViewItem item = new ListViewItem(row["ID"].ToString());
                item.SubItems.Add(row["Name"].ToString());
                item.SubItems.Add(row["Type"].ToString());
                this.lvCategory.Items.Add(item);
            }    
            //this.DisplayCategory(sqlDataReader);
            sqlConnection.Close();
        }
       private void DisplayCategory(SqlDataReader reader)
        {
            lvCategory.Items.Clear();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["ID"].ToString());
                lvCategory.Items.Add(item);
                item.SubItems.Add(reader["Name"].ToString());
                item.SubItems.Add(reader["Type"].ToString());
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string connectionString = "server=.; database = RestaurantManagement; Integrated Security = true;";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            string query = "Insert into Category(Name,[Type])" + "Values(N'" + txtName.Text + "', " + (string.Compare(txtType.Text,"Thức uống")==0?0:1) + ")"; ;
            sqlCommand.CommandText = query;
            sqlConnection.Open();
            int numOfRowEffected = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

            if (numOfRowEffected == 1)
            {
                MessageBox.Show("Thêm nhóm món ăn thành công");
                btnLoad.PerformClick();
                txtName.Text = "";
                txtType.Text = "";
            }
            else
                MessageBox.Show("Đã có lỗi xảy ra. Vui lòng thử lại");
        }

        private void lvCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lvCategory_Click(object sender, EventArgs e)
        {
            ListViewItem item = lvCategory.SelectedItems[0];
            txtID.Text = item.Text;
            txtName.Text=item.SubItems[1].Text;
            txtType.Text = item.SubItems[2].Text=="0"?"Thức uống":"Đồ ăn";

            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int type = 0;
            if (txtType.Text == "Đồ ăn")
                type = 1; ;
            string connectionString = "server=.; database = RestaurantManagement; Integrated Security = true;";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = "Update Category Set Name = N'" + txtName.Text +
                                                    "',[Type]=N'" + type  +
                                                    "' Where ID = " + txtID.Text;
            txtTest.Text = sqlCommand.CommandText;
            sqlConnection.Open();
            int numOfRowsEffected = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (numOfRowsEffected == 1)
            {
                ListViewItem item = lvCategory.SelectedItems[0];
                item.SubItems[1].Text = txtName.Text;
                item.SubItems[2].Text = type.ToString();

                txtID.Text = "";
                txtName.Text = "";
                txtType.Text = "";

                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
                MessageBox.Show("Cập nhật nhóm món ăn thành công");
            }
            else
                MessageBox.Show("Đã có lỗi xảy ra. Vui lòng thử lại");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string connectionString = "server=.; database = RestaurantManagement; Integrated Security = true;";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = "Delete from Category" +
                                                    " Where ID = " + txtID.Text;
            txtTest.Text = sqlCommand.CommandText;
            sqlConnection.Open();
            int numOfRowsEffected = sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            if (numOfRowsEffected == 1)
            {
                //ListViewItem item = lvCategory.SelectedItems[0];
                //lvCategory.Items.Remove(item);
                this.btnLoad.PerformClick();
                txtID.Text = "";
                txtName.Text = "";
                txtType.Text = "";

                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
                MessageBox.Show("Xóa nhóm món ăn thành công");
            }
            else
                MessageBox.Show("Đã có lỗi xảy ra. Vui lòng thử lại");
        }

        private void tsmDelete_Click(object sender, EventArgs e)
        {
            if(lvCategory.SelectedItems.Count > 0) { btnDelete.PerformClick(); }
        }

        private void tsmViewFood_Click(object sender, EventArgs e)
        {
            if(txtID.Text!="")
            {
                btnDelete foodform = new btnDelete();
                foodform.Show(this);
                foodform.LoadFood(Convert.ToInt32(txtID.Text));
            }    
        }
    }
}
