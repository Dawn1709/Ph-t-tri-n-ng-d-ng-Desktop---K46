﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Lab06_Basic_Command
{
    public partial class btnDelete : Form
    {
        public btnDelete()
        {
            InitializeComponent();
        }
        public void LoadFood(int categoryID)
        {
            string connectionString = "server=.; database = RestaurantManagement; Integrated Security = true;";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = "Select Name From Category Where ID = "+categoryID;
            sqlConnection.Open();
            string catName = sqlCommand.ExecuteScalar().ToString();
            this.Text = "Danh sách các món ăn thuộc nhóm: " + catName;
            sqlCommand.CommandText = "Select * from Food Where FoodCategoryID = " + categoryID;
            this.txtTest.Text = sqlCommand.CommandText;
            SqlDataAdapter da = new SqlDataAdapter(sqlCommand);
            DataSet dt = new DataSet();
            da.Fill(dt,"Food");
            dgvFood.DataSource = dt.Tables["Food"];
            sqlConnection.Close();
            sqlConnection.Dispose();
            da.Dispose();
         }

        private void btnSave_Click(object sender, EventArgs e)
        {
           
            string connectionString = "server=.; database = RestaurantManagement; Integrated Security = true;";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand cmd = sqlConnection.CreateCommand();
            sqlConnection.Open();
            for (int i = 0; i < dgvFood.Rows.Count-1; i++)
            {
                cmd.CommandText = "EXECUTE Food_InsertUpdateDelete @id , @name, @unit, @foodCategoryID, @price, @notes, 1";

                // Them tham so vao doi tượng Command
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters.Add("@name", SqlDbType.NVarChar, 1000);
                cmd.Parameters.Add("@unit", SqlDbType.NVarChar, 100);
                cmd.Parameters.Add("@foodCategoryId", SqlDbType.Int);
                cmd.Parameters.Add("@price", SqlDbType.Int);
                cmd.Parameters.Add("@notes", SqlDbType.NVarChar, 3000);

                //cmd.Parameters["@id"].Direction = ParameterDirection.Output;

                // Truyen gia tri vao thu tuc qua tham so
                cmd.Parameters["@id"].Value = dgvFood[0, i].Value;
                cmd.Parameters["@name"].Value = dgvFood[1, i].Value;
                cmd.Parameters["@unit"].Value = dgvFood[2,i].Value;
                cmd.Parameters["@foodCategoryId"].Value = dgvFood[3,i].Value;
                cmd.Parameters["@price"].Value = dgvFood[4,i].Value;
                cmd.Parameters["@notes"].Value = dgvFood[5,i].Value;

                cmd.ExecuteNonQuery();
            }

            sqlConnection.Close();
            cmd.Dispose();
        }

        private void dgvFood_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            //string header = this.dgvFood.Columns[e.ColumnIndex].HeaderText;
            //var value = this.dgvFood[e.ColumnIndex, e.RowIndex].Value;
            //var foodID = this.dgvFood[0,e.RowIndex].Value;
            //string connectionString = "server=.; database = RestaurantManagement; Integrated Security = true;";
            //SqlConnection sqlConnection = new SqlConnection(connectionString);
            //SqlCommand sqlCommand = sqlConnection.CreateCommand();
            //sqlCommand.CommandText = "Update Food Set " + header + "= N'" + value +
            //                                        "' Where ID = " + foodID;
            //txtTest.Text = foodID.ToString();
            //sqlConnection.Open();
            //int numOfRowsEffected = sqlCommand.ExecuteNonQuery();
            //sqlConnection.Close();
        }
       
           
    }
}
